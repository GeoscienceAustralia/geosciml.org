Instances designed to validate against trunk XML Schemas and optionally certain Schematrons.
Used to help testing of production of Schemas and Schematrons.