This is the first release of GeoSciML, version 1.0.0. 
These documents were copied across from the draft ../../draft on 2006-01-16
The draft will be left in place, since the Subversion repository records the development history. 

