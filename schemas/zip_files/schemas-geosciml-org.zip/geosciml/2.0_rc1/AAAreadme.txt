This directory contains the XML Schema for GeoSciML v2.0 release candidate 1. 
The contents correspond to "stable" version described at 
https://www.seegrid.csiro.au/twiki/bin/view/CGIModel/GeoSciMLModel#GeoSciML_v2_stable_version

SJDC 2008-02-26
SJDC 2008-04-14