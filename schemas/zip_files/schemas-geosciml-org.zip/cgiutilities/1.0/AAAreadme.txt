This directory contains the Utilities schema issued by CGI and used by GeoSciML v2.0
It defines XML components for 
   * NAME LOCALIZATION
which extend components defined in GML 3.1.1

SJDC 2008-02-26
SJDC 2008-04-14
SJDC 2008-05-05