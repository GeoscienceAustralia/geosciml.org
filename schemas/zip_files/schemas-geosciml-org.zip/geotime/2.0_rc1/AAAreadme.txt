This directory contains the XML Schema for the Geologic Timescale GeoTime v2.0 release candidate 1
The model is described at https://www.seegrid.csiro.au/twiki/bin/view/CGIModel/GeologicTime

SJDC 2008-02-26
SJDC 2008-04-14