This directory contains the XML Schema for GeoTime v2.0 release candidate 2. 
The contents correspond to "stable" version described at 
https://www.seegrid.csiro.au/twiki/bin/view/CGIModel/GeoSciMLModel#GeoSciML_v2_stable_version

SJDC 2008-07-02