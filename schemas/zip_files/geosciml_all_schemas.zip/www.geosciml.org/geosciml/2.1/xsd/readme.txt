GeoSciML version 2.1 schema files

These schema files are minor extensions of the v2.0 GeoSciML schemas.  Refer to documentation in the 'doc' directory.

Ollie Raymond 3 Mar 2010